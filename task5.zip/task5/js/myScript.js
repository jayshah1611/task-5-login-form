var attempt = 3;
            function checkPass() {
                var name = document.getElementById("name").value;
                var pass = document.getElementById("pass").value;
                if (name == "jay" && pass == "123") {
                    alert("LogIn SuccessFully");
                    document.getElementById("name").value = "";
                    document.getElementById("pass").value = "";
                    location.replace("home.html")
                }

               
                else {
                    if (attempt == 0) {
                        alert("No Login Attempts Available");
                    }
                    else {
                        attempt = attempt - 1;
                        alert("Login Failed, Now you have Only " + attempt + " Attempts Available");
                        if (attempt == 0) {
                            document.getElementById("name").disabled = true;
                            document.getElementById("pass").disabled = true;
                            document.getElementById("form1").disabled = true;
                        }
                    }
                }

                return false;
            }

            function backToHome(){
                location.replace("index.html")

            }